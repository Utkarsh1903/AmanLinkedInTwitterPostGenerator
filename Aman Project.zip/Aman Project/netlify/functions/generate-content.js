exports.handler = async function (event) {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
      },
      body: "",
    };
  }

  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  const GROK_API_KEY = process.env.GROK_API_KEY;
  if (!GROK_API_KEY) {
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "GROK_API_KEY environment variable is not set." }),
    };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return {
      statusCode: 400,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Invalid JSON body." }),
    };
  }

  const { topic, context: userContext, tone } = body;
  if (!topic || topic.trim().length === 0) {
    return {
      statusCode: 400,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Topic is required." }),
    };
  }

  const toneDescriptions = {
    professional: "professional and polished",
    casual: "casual and conversational",
    inspirational: "inspirational and motivating",
    technical: "technical and detailed",
  };
  const selectedTone = toneDescriptions[tone] || "professional and polished";
  const contextClause = userContext ? `\n\nAdditional context: ${userContext}` : "";

  const linkedInPrompt = `You are a professional LinkedIn content writer. Generate a high-quality, copy-friendly LinkedIn post based on the following topic.

Topic: ${topic}${contextClause}

Requirements:
- Tone: ${selectedTone}
- Start with a powerful hook (first line should stop the scroll)
- Use short paragraphs (2-3 sentences max each)
- Include 3-5 key insights or takeaways
- Add relevant emojis sparingly but effectively
- End with a thought-provoking question or call-to-action to drive engagement
- Include 5-8 relevant hashtags at the end
- Length: 150-300 words
- Sound human and authentic, NOT like AI-generated content
- Format with line breaks for readability

Return ONLY the LinkedIn post text, nothing else.`;

  const xThreadPrompt = `You are a Twitter/X content strategist. Generate a compelling X (Twitter) thread based on the following topic.

Topic: ${topic}${contextClause}

Requirements:
- Tone: ${selectedTone}
- Create a thread of 4-6 tweets
- Each tweet MUST be under 280 characters
- Format each tweet as: "1/ [tweet text]", "2/ [tweet text]", etc.
- First tweet must be a powerful hook that makes people click "show more"
- Each tweet should stand on its own but flow into the next
- Use emojis strategically
- Last tweet should include a call-to-action or key takeaway
- Add 2-3 hashtags only in the last tweet
- Sound punchy, direct, and human

Return ONLY the thread tweets, numbered (1/, 2/, etc.), nothing else.`;

  async function callGrok(prompt) {
    const response = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${GROK_API_KEY}`,
      },
      body: JSON.stringify({
        model: "grok-3",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.85,
        max_tokens: 1024,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Grok API error ${response.status}: ${errText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content.trim();
  }

  try {
    const [linkedInPost, xThread] = await Promise.all([
      callGrok(linkedInPrompt),
      callGrok(xThreadPrompt),
    ]);

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ linkedInPost, xThread }),
    };
  } catch (err) {
    console.error("Generation error:", err);
    return {
      statusCode: 502,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: err.message || "Failed to generate content." }),
    };
  }
};
